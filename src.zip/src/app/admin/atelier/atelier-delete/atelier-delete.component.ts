import { Component } from '@angular/core';

@Component({
  selector: 'app-atelier-delete',
  templateUrl: './atelier-delete.component.html',
  styleUrls: ['./atelier-delete.component.css']
})
export class AtelierDeleteComponent {

}
