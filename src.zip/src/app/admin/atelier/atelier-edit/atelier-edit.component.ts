import { Component } from '@angular/core';

@Component({
  selector: 'app-atelier-edit',
  templateUrl: './atelier-edit.component.html',
  styleUrls: ['./atelier-edit.component.css']
})
export class AtelierEditComponent {

}
