import { Component } from '@angular/core';

@Component({
  selector: 'app-user-del',
  templateUrl: './user-del.component.html',
  styleUrls: ['./user-del.component.css']
})
export class UserDelComponent {

}
