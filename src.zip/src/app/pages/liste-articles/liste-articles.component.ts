import { Component } from '@angular/core';

@Component({
  selector: 'app-tous-articles',
  templateUrl: './liste-articles.component.html',
  styleUrls: ['./liste-articles.component.css']
})
export class ListeArticlesComponent {

}
