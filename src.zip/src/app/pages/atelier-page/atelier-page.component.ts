import { Component } from '@angular/core';

@Component({
  selector: 'app-atelier-page',
  templateUrl: './atelier-page.component.html',
  styleUrls: ['./atelier-page.component.css']
})
export class AtelierPageComponent {

}
