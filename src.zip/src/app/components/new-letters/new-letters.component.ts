import { Component } from '@angular/core';

@Component({
  selector: 'app-new-letters',
  templateUrl: './new-letters.component.html',
  styleUrls: ['./new-letters.component.css']
})
export class NewLettersComponent {

}
