import { Component } from '@angular/core';

@Component({
  selector: 'app-tendance',
  templateUrl: './tendance.component.html',
  styleUrls: ['./tendance.component.css']
})
export class TendanceComponent {

}
