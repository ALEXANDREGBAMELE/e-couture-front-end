import { Component } from '@angular/core';

@Component({
  selector: 'app-baniere',
  templateUrl: './baniere.component.html',
  styleUrls: ['./baniere.component.css']
})
export class BaniereComponent {

}
