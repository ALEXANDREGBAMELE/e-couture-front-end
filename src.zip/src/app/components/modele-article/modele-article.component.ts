import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-modele-article',
  templateUrl: './modele-article.component.html',
  styleUrls: ['./modele-article.component.css']
})
export class ModeleArticleComponent {

  carouselData: any[] = [];

 }
