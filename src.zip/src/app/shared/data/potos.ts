export class Potos {
}
