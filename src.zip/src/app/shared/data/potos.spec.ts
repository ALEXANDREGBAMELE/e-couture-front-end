import { Potos } from './potos';

describe('Potos', () => {
  it('should create an instance', () => {
    expect(new Potos()).toBeTruthy();
  });
});
