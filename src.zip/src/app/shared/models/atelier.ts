export interface Atelier{
    atelierId? : number;
    nomAtelier? : string;
    adresse? : string;
    descriptionAtelier? : string;
    ville? : string;
    codePostal? : string;
    image? : string;
    // rating? : number

}