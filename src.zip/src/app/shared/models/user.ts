export interface User{
    userId? : number;
    nom? : string;
    prenom? : number;
    telephone? : string;
    dateNaissance? : Date;
    mail? : string;
    image? : string;
    adresse? : string;
    ville? : string;
    codePostal? : string;
    motDePasse? : any;
    confirmMotDePasse? : any;

}