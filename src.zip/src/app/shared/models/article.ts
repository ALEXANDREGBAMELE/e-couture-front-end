export interface Article{
    article_id? : number;
    libelle? : string;
    prix? : number;
    description? : string;
    date? : Date;
    duree? : number;
    image? : string;
    rating? : number

}