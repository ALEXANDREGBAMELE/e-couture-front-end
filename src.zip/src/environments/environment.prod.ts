// Fichier environment.prod.ts

export const environment = {
    production: true,
    apiUrl: 'https://my-app.com/api',
  };